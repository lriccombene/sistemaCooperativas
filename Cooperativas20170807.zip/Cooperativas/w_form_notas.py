import sys
from PyQt5.QtWidgets import QApplication,QDialog,QMessageBox,QTableWidgetItem,QWidget
from PyQt5 import uic
from form_notas import Ui_form_notas
from PyQt5.QtCore import pyqtRemoveInputHook
from E_notas import E_notas

class notas(QDialog):
    obj_form= Ui_form_notas()
    id_party=0
    id_asoc=0

    def __init__(self):
        QDialog.__init__(self)
        self.obj_form= Ui_form_notas()
        self.obj_form.setupUi(self)
        self.obj_form.boton_notas_guardar.clicked.connect(self.notas_guardar)
        self.obj_form.tw_lista_notas.cellClicked.connect(self.seleccion_item_tabla)
        obj_notas = E_notas()
        list_notas = obj_notas.get_notas()
        for item in list_notas:
            rowPosition = self.obj_form.tw_lista_notas.rowCount()
            self.obj_form.tw_lista_notas.insertRow(rowPosition)
            self.obj_form.tw_lista_notas.setItem(rowPosition , 0, QTableWidgetItem(str(item.titulo)))
            self.obj_form.tw_lista_notas.setItem(rowPosition , 1, QTableWidgetItem(str(item.fecha)))
            self.obj_form.tw_lista_notas.setItem(rowPosition , 2, QTableWidgetItem(str(item.descripcion)))
            self.obj_form.tw_lista_notas.setItem(rowPosition , 3, QTableWidgetItem(str(item.tipo)))


    def notas_guardar(self):
        obj_notas = E_notas()
        obj_notas.titulo = self.obj_form.lne_notas_titulo.text()
        obj_notas.fecha =  self.obj_form.dte_fec_notas.text()
        obj_notas.descripcion =  self.obj_form.txt_detalle_notas.toPlainText()
        obj_notas.tipo = self.obj_form.cbx_nota_tipo.currentText()
        obj_notas.guardar(obj_notas)

    def seleccion_item_tabla(self, clickedIndex):
        #pyqtRemoveInputHook()
        #import pdb; pdb.set_trace()
        self.obj_form.txt_notas_busqueda.setPlainText(self.obj_form.tw_lista_notas.item(clickedIndex,2).text())


app = QApplication(sys.argv)
dialogo= notas()
dialogo.show()
app.exec_()
